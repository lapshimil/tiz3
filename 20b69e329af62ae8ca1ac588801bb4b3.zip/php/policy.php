

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- mobile metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1">
    <!-- site metas -->
     
    <title>Politica sulla privacy</title>
    <!-- bootstrap css -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- style css -->
    <link rel="stylesheet" href="css/style.css">
    <!-- Responsive-->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Scrollbar Custom CSS -->
    <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
    <!-- Tweaks for older IEs-->
    <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
</head>
<!-- body -->
<body class="main-layout">

<!-- header -->
<header>
    <!-- header inner -->
    <div class="header">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                    <div class="full">
                        <div class="center-desk">
                            <div class="logo">
                                <a href="index.php"><h2>Squat</h2></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
                    <div class="header_information">
                        <nav class="navigation navbar navbar-expand-md navbar-dark ">
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="navbar-toggler-icon"></span>
                            </button>
                            <div class="collapse navbar-collapse" id="navbarsExample04">
                                <ul class="navbar-nav mr-auto">
                                    <li class="nav-item">
                                        <a class="nav-link" href="index.php">Home</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="blog.php">Articoli</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="contact.php">Contatti</a>
                                    </li>
                                    <li class="nav-item active">
                                        <a class="nav-link" href="policy.php">Politica sulla privacy</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="terms.php">Termini e condizioni</a>
                                    </li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
<!-- end header inner -->
<!-- end header -->
<!-- banner -->

<!-- about -->
<div id="about"  class="about">
    <div class="container">
        <h1>Politica sulla privacy</h1>
        <div class="content">
             Politica in materia di trattamento dei dati personali
 1. Disposizioni generali
La presente informativa trattamento dei dati personali redatta in conformità con i requisiti della
della legge del 27.07.2006. N. 152-FZ «dati personali» e definisce la modalità di trattamento dei dati personali
e le misure di sicurezza personali dati Mihailova Ivan Sergeevic (di seguito Gestore).
L'operatore si pone un obiettivo fondamentale e condizione per l'esercizio della propria attività il rispetto dei diritti e
libertà dell'uomo e del cittadino al trattamento dei propri dati personali, compresa la protezione dei diritti alla privacy
vita privata, personale e familiare.
Vero la politica dell'Operatore in relazione al trattamento dei dati personali (di seguito – Politica) si applica a tutte le informazioni
che l'Operatore può ottenere sui visitatori del sito <span class="server-name"></span>.
            I concetti di base utilizzati in Politica
Trattamento automatizzato dei dati personali – il trattamento dei dati personali con strumenti di informatica;
Blocco dei dati personali – l'interruzione temporanea del trattamento dei dati personali (tranne se
il trattamento è necessario per il perfezionamento dei dati personali);
Sito web – un insieme di grafici e materiale informativo, nonché programmi per COMPUTER e database, fornendo
accessibilità in rete internet all'indirizzo di rete <span class="server-name"></span>;
             Il sistema informativo dei dati personali — un insieme di contenuti nei database i dati personali, e garantire
il loro trattamento delle tecnologie dell'informazione e mezzi tecnici;
Spersonalizzazione dei dati personali — azione, in cui non è possibile determinare senza l'utilizzo di ulteriori
informazioni di appartenenza dei dati personali di un Utente specifico o un altro soggetto dei dati personali;
Il trattamento dei dati personali – ogni azione (l'operazione) o un insieme di azioni (operazioni)
con l'uso di strumenti di automazione o senza l'utilizzo di tali fondi con i dati personali, compresa la raccolta, la registrazione,
sistematizzazione, l'accumulo, la conservazione, la raffinatezza (l'aggiornamento, la modifica), l'estrazione, l'utilizzo, il trasferimento (diffusione, 
la fornitura, l'accesso), depersonalizzazione, blocco, cancellazione, distruzione dei dati personali;
L'operatore di un ente pubblico, l'autorità comunale, persona fisica o giuridica, da solo o insieme
con altre persone organizzano e (o) effettuano il trattamento dei dati personali, così come definiscono gli obiettivi del trattamento
dei dati personali, la composizione dei dati personali, oggetto di trattamento, le azioni (operazioni), commessi con personali dati;
Dati personali – tutte le informazioni relative, direttamente o indirettamente, a una o definita dall'Utente
sito web <span class="server-name"></span>;
            Un utente qualsiasi visitatore del sito web <span class="server-name"></span>;
             Il conferimento dei dati personali – azioni finalizzate alla divulgazione dei dati personali specifico
persona o di un certo gruppo di persone;
La diffusione dei dati personali – tutte le azioni finalizzate alla divulgazione dei dati personali non definita
cerchia di persone (la trasmissione di dati personali) o a familiarizzare con i dati personali illimitato cerchia di persone, tra cui 
la pubblicazione di dati personali in media, sistemazione in un sistema di reti di telecomunicazioni 
o concedere l'accesso ai dati personali in qualsiasi altro modo;
Trasferimento transfrontaliero dei dati personali – il trasferimento dei dati personali nel territorio di uno stato straniero all'autorità 
le autorità di uno stato straniero, straniero, persona fisica o straniero, persona giuridica;
La distruzione dei dati personali – ogni azione, in cui i dati personali vengono cancellati definitivamente dal 
l'impossibilità di un ulteriore il recupero del contenuto dei dati personali nel sistema informativo dei dati personali e 
(o) cui vengono distrutti supporto di memorizzazione fisica dei dati personali.

L'operatore può gestire i seguenti i dati personali dell'Utente
Cognome, nome;
L'indirizzo di posta elettronica;
Numeri di telefono;
Anno, mese, data e luogo di nascita;
Le foto;
Anche sul sito avviene la raccolta e il trattamento cui i dati sui visitatori (incl. di file «cookie») tramite i servizi di internet-statistica (Yandex Metrica e Google Analytics e altri).
I dati di cui sopra di seguito i Criteri combinati in comune il concetto di dati Personali.

Obiettivi il trattamento dei dati personali
Lo scopo del trattamento dei dati personali dell'Utente — informare l'Utente tramite l'invio di e-mail; 
fornire l'accesso all'Utente ai servizi, informazioni e/o materiali contenuti nel sito web.
Inoltre, l'Operatore ha il diritto di guidare l'Utente viene informato nuovi prodotti e servizi, offerte speciali e eventi diversi. L'utente può sempre scegliere di non ricevere comunicazioni, dando all'Operatore mail all'indirizzo di posta elettronica policy@<span
                class="server-name"></span>  con la dicitura «Rifiuto di notifiche di nuovi prodotti e servizi e offerte speciali».
Anonimi i dati degli Utenti raccolti tramite i servizi di internet-le statistiche servono per raccogliere informazioni sulle attività degli Utenti sul sito, migliorare la qualità del sito e dei suoi contenuti.

La base giuridica del trattamento dei dati personali
Il titolare tratta i dati personali dell'Utente solo in caso di riempimento e/o per inviare dall'Utente tramite appositi moduli presenti su questo sito <span
                class="server-name"></span> . Riempire i moduli e/o inviando i propri dati personali all'Operatore, l'Utente esprime il proprio consenso con la presente Informativa.
L'operatore elabora i dati anonimi sull'Utente nel caso in cui ciò sia consentito dalle impostazioni del browser dell'Utente (incluso il salvataggio di file «cookie» e l'uso di la tecnologia JavaScript).

Le modalità di raccolta, archiviazione, trasmissione e altri tipi di trattamento dei dati personali
La sicurezza dei dati personali, che vengono gestiti da un Operatore, è assicurata mediante la realizzazione giuridici, organizzativi e tecnici misure necessarie per eseguire nel pieno rispetto delle norme di la legislazione in materia di protezione dei dati personali.
L'operatore garantisce la sicurezza dei dati personali e adotta tutte le misure che escludano l'accesso ai dati personali di persone non autorizzate.
I dati personali dell'Utente mai, in nessun caso, non saranno comunicati a terzi, fatta eccezione per casi associati con l'esecuzione della legislazione vigente.
In caso di inesattezze dei dati personali, l'Utente può aggiornare da soli, attraverso il rinvio all'Operatore una notifica all'indirizzo di posta elettronica dell'Operatore policy@<span
                class="server-name"></span> con la dicitura «Aggiornamento dei dati personali».
Il periodo di trattamento dei dati personali è illimitato. L'utente può in qualsiasi momento revocare il consenso al trattamento dei dati personali, inviando all'Operatore una notifica tramite e-mail all'indirizzo di posta elettronica dell'Operatore policy@<span
                class="server-name"></span>  con la dicitura «Revoca del consenso al trattamento dei dati personali».

Trasferimento transfrontaliero di dati personali
L'operatore prima di iniziare l'esercizio transfrontaliero trasferimento di dati personali è tenuto a verificare che straniero dallo stato sul territorio del quale si presume di effettuare il trasferimento dei dati personali, affidabile protezione dei diritti dei soggetti dei dati personali.
Trasferimento transfrontaliero di dati personali a paesi stranieri che non soddisfano i requisiti di cui sopra, può essere effettuata solo in caso di presenza di consenso in forma scritta, di dati personali oggetto di trasferimento transfrontaliero i suoi dati personali e/o esecuzione del contratto, la parte che è il soggetto dei dati personali.

Disposizioni finali
L'utente può ottenere eventuali chiarimenti su questioni di interesse relative al trattamento dei propri dati personali, rivolgendosi all'Operatore tramite e-mail policy@<span
                class="server-name"></span>.
            In questo documento verranno riportate le eventuali modifiche dei criteri di trattamento dei dati personali da parte dell'Operatore. La politica è valida a tempo indeterminato fino alla sostituzione con una nuova versione.
 La versione attuale Politica di libero accesso si trova in Internet all'indirizzo <span class="server-name"></span>
        </div>
    </div>
</div>
<!-- end about -->

<!--  footer -->
<footer>
    <div class="footer">
        <div class="copyright">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <p>©
                            <script>document.write(new Date().getFullYear())</script> All Rights Reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<div class='cookie-banner'>
    <p>
        Il sito utilizza i cookie. Essi consentono di riconoscere l'utente e di ottenere informazioni sulle tue esperienze.Continuando la navigazione nel sito, sono d'accordo con l'utilizzo dei cookie il proprietario del sito in conformità con  <a target="_blank" href="https://en.wikipedia.org/wiki/HTTP_cookie">Cookie policy</a>
    </p>
    <button class='close-cookie'>&times;</button>
</div>
<script>
    window.onload = function () {
        $('.close-cookie').click(function () {
            $('.cookie-banner').fadeOut();
        })
    }
</script>
<script>
    let elems = document.querySelectorAll('.server-name');
    elems.forEach((elem) => {
        elem.innerHTML = window.location.hostname
    })
</script>
<!-- end footer -->
<!-- Javascript files-->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/jquery-3.0.0.min.js"></script>

<!-- sidebar -->
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
</body>
</html>

